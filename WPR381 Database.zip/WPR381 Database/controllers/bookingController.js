const Booking = require("../models/Booking");
const Event = require("../models/Event");

exports.bookTicket = async (req, res) => {

    try {

        const { eventId, quantity } = req.body;

        const event = await Event.findById(eventId);

        if(!event){
            return res.send("Event not found");
        }

        if(event.ticketsSold + quantity > event.capacity){
            return res.send("Not enough tickets available");
        }

        const totalPrice = quantity * event.price;

        const booking = new Booking({

            user: req.session.user.id,
            event: event._id,
            quantity,
            totalPrice

        });

        await booking.save();

        event.ticketsSold += quantity;

        await event.save();

        res.send("Booking successful");

    } catch (error) {

        console.log(error);

    }

};

exports.userBookings = async (req, res) => {

    try {

        const bookings = await Booking.find({
            user: req.session.user.id
        }).populate("event");

        res.json(bookings);

    } catch (error) {

        console.log(error);

    }

};