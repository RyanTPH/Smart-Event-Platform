const Enquiry = require("../models/Enquiry");

exports.submitEnquiry = async (req, res) => {

    try {

        const enquiry = new Enquiry(req.body);

        await enquiry.save();

        res.send("Enquiry submitted");

    } catch (error) {

        console.log(error);

    }

};

exports.getEnquiries = async (req, res) => {

    try {

        const enquiries = await Enquiry.find();

        res.json(enquiries);

    } catch (error) {

        console.log(error);

    }

};