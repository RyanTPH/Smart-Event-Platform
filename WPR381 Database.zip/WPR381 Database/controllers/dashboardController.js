const Booking = require("../models/Booking");

exports.adminDashboard = async (req, res) => {

    try {

        const totalBookings = await Booking.countDocuments();

        const revenue = await Booking.aggregate([
            {
                $group: {
                    _id: null,
                    totalRevenue: { $sum: "$totalPrice" }
                }
            }
        ]);

        const popularEvents = await Booking.aggregate([
            {
                $group: {
                    _id: "$event",
                    ticketsSold: { $sum: "$quantity" }
                }
            },
            {
                $sort: { ticketsSold: -1 }
            }
        ]);

        res.json({
            totalBookings,
            revenue,
            popularEvents
        });

    } catch (error) {

        console.log(error);

    }

};