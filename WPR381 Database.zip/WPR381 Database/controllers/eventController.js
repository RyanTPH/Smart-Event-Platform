const Event = require("../models/Event");

exports.createEvent = async (req, res) => {

    try {

        const event = new Event(req.body);

        await event.save();

        res.send("Event created");

    } catch (error) {

        console.log(error);

    }

};

exports.getEvents = async (req, res) => {

    try {

        const events = await Event.find();

        res.json(events);

    } catch (error) {

        console.log(error);

    }

};

exports.updateEvent = async (req, res) => {

    try {

        await Event.findByIdAndUpdate(req.params.id, req.body);

        res.send("Event updated");

    } catch (error) {

        console.log(error);

    }

};

exports.deleteEvent = async (req, res) => {

    try {

        await Event.findByIdAndDelete(req.params.id);

        res.send("Event deleted");

    } catch (error) {

        console.log(error);

    }

};
