const User = require("../models/User");
const bcrypt = require("bcryptjs");

exports.register = async (req, res) => {

    try {

        const { name, email, password } = req.body;

        const existingUser = await User.findOne({ email });

        if(existingUser){
            return res.send("User already exists");
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            name,
            email,
            password: hashedPassword
        });

        await user.save();

        res.send("Registration successful");

    } catch (error) {

        console.log(error);

    }

};

exports.login = async (req, res) => {

    try {

        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if(!user){
            return res.send("User not found");
        }

        const match = await bcrypt.compare(password, user.password);

        if(!match){
            return res.send("Incorrect password");
        }

        req.session.user = {
            id: user._id,
            role: user.role
        };

        res.send("Login successful");

    } catch (error) {

        console.log(error);

    }

};s