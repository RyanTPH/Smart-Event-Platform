const express = require("express");
const session = require("express-session");
const dotenv = require("dotenv");
const methodOverride = require("method-override");

const connectDB = require("./config/db");

dotenv.config();

connectDB();

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(methodOverride("_method"));

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false
}));

app.set("view engine", "ejs");

app.use("/auth", require("./routes/authRoutes"));
app.use("/events", require("./routes/eventRoutes"));
app.use("/bookings", require("./routes/bookingRoutes"));
app.use("/dashboard", require("./routes/dashboardRoutes"));
app.use("/enquiries", require("./routes/enquiryRoutes"));

module.exports = app;